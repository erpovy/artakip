"use strict";exports.id=6384,exports.ids=[6384],exports.modules={36384:(e,t,r)=>{r.d(t,{GB:()=>$,I8:()=>h,Mr:()=>c,NR:()=>x,PY:()=>T,Qx:()=>k,XZ:()=>S,l4:()=>f,n_:()=>y,wI:()=>g});var o=r(92048),i=r.n(o),a=r(19801),n=r.n(a),l=r(55315),d=r.n(l),s=r(56742),p=r(39812),m=r(82208);function f(e){return e.userEmailVerified?"DOWN"!==e.eventType||e.notifyOnDown?"UP"!==e.eventType||e.notifyOnUp?"SSL"!==e.eventType||e.notifyOnSslExpiry?!function(e,t,r,o="Europe/Istanbul"){let i;if(!t||!r)return!1;let a=e=>{let t=/^(\d{1,2}):(\d{2})$/.exec(e.trim());if(!t)return null;let r=Number(t[1]),o=Number(t[2]);return r<0||r>23||o<0||o>59?null:60*r+o},n=a(t),l=a(r);if(null===n||null===l||n===l)return!1;try{let t=new Intl.DateTimeFormat("en-GB",{hour:"2-digit",minute:"2-digit",hour12:!1,timeZone:o}).formatToParts(e),r=Number(t.find(e=>"hour"===e.type)?.value??0),a=Number(t.find(e=>"minute"===e.type)?.value??0);i=r%24*60+a}catch{i=60*e.getUTCHours()+e.getUTCMinutes()}return n<l?i>=n&&i<l:i>=n||i<l}(e.now??new Date,e.quietHoursStart,e.quietHoursEnd,e.timezone)?{shouldSendNow:!0,deferForQuietHours:!1}:{shouldSendNow:!1,deferForQuietHours:!0,reason:"Sessiz saatler aktif; bildirim sessiz saat bitişinde toplu g\xf6nderilecek."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı SSL bildirimlerini kapattı."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı a\xe7ılma bildirimlerini kapattı."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı kapanma bildirimlerini kapattı."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı e-posta adresi doğrulanmamış."}}function c(e,t=20){return e>=t}function u(){return process.env.NEXT_PUBLIC_APP_URL||process.env.NEXTAUTH_URL||"http://localhost:3000"}function b(e,t,r){let o=`${u()}/dashboard/settings`;return`<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>${e}</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#f8fafc; padding:24px; color:#0f172a;">
  <div style="max-width:600px; margin:0 auto; background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; overflow:hidden;">
    <div style="background:${t}; color:#ffffff; padding:16px 24px; font-weight:700; font-size:18px;">
      Artakip Uptime — ${e}
    </div>
    <div style="padding:24px; line-height:1.6; font-size:15px;">
      ${r}
    </div>
    <div style="background:#f1f5f9; padding:16px 24px; font-size:12px; color:#64748b; border-top:1px solid #e2e8f0;">
      Bu e-posta Artakip Uptime izleme servisiniz tarafından otomatik g\xf6nderilmiştir.<br/>
      <a href="${o}" style="color:#2563eb; text-decoration:underline;">Bildirim ayarlarını değiştir veya abonelikten \xe7ık</a>
    </div>
  </div>
</body>
</html>`}function x(e){let t=e.timezone||"Europe/Istanbul",r=(0,p.v)(e.startedAt,t),o=`${u()}/dashboard/monitors/${e.monitorId}`,i=`${u()}/dashboard/settings`;return{subject:`🔴 [KAPANDI] ${e.monitorName} erişilemiyor`,html:b("Site Kapandı Uyarısı","#dc2626",`<p><strong>${e.monitorName}</strong> isimli web siteniz yapılan kontrolde yanıt vermedi.</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Site Adı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.monitorName}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">URL</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><a href="${e.url}">${e.url}</a></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Kapanma Zamanı (${t})</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;">${r}</td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Hata Nedeni</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#dc2626;">${e.reason}</td></tr>
     </table>
     <p style="margin-top:20px;">
       <a href="${o}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Panelde G\xf6r\xfcnt\xfcle</a>
     </p>`),text:`[KAPANDI] ${e.monitorName}
URL: ${e.url}
Kapanma Zamanı (${t}): ${r}
Hata Nedeni: ${e.reason}
Panel: ${o}
Bildirim Ayarları / Abonelikten \xc7ık: ${i}`}}function g(e){let t=e.timezone||"Europe/Istanbul",r=(0,p.v)(e.resolvedAt,t),o=(0,p.n)(e.durationMs),i=`${u()}/dashboard/monitors/${e.monitorId}`,a=`${u()}/dashboard/settings`;return{subject:`🟢 [A\xc7ILDI] ${e.monitorName} tekrar yayında (${o} kesinti)`,html:b("Site Tekrar A\xe7ıldı","#16a34a",`<p><strong>${e.monitorName}</strong> isimli web siteniz tekrar erişilebilir duruma geldi.</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Site Adı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.monitorName}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">URL</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><a href="${e.url}">${e.url}</a></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">A\xe7ılma Zamanı (${t})</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;">${r}</td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Toplam Kesinti S\xfcresi</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; font-weight:700;">${o}</td></tr>
     </table>
     <p style="margin-top:20px;">
       <a href="${i}" style="display:inline-block; background:#16a34a; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Olay Ge\xe7mişini İncele</a>
     </p>`),text:`[A\xc7ILDI] ${e.monitorName}
URL: ${e.url}
A\xe7ılma Zamanı (${t}): ${r}
Toplam Kesinti S\xfcresi: ${o}
Panel: ${i}
Bildirim Ayarları / Abonelikten \xc7ık: ${a}`}}function y(e){let t=e.timezone||"Europe/Istanbul",r=(0,p.v)(e.expiresAt,t),o=`${u()}/dashboard/monitors/${e.monitorId}`,i=`${u()}/dashboard/settings`;return{subject:`⚠️ [SSL UYARISI] ${e.monitorName} SSL sertifikasının bitmesine ${e.daysRemaining} g\xfcn kaldı`,html:b("SSL Sertifika S\xfcresi Doluyor","#d97706",`<p><strong>${e.monitorName}</strong> sitenizin SSL sertifikasının s\xfcresi yakında dolacaktır.</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Site Adı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.monitorName}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Kalan G\xfcn</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#d97706; font-weight:700;">${e.daysRemaining} g\xfcn</td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Bitiş Tarihi</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;">${r}</td></tr>
     </table>
     <p><a href="${o}" style="display:inline-block; background:#d97706; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Site Detayına Git</a></p>`),text:`[SSL UYARISI] ${e.monitorName} (${e.url})
Kalan G\xfcn: ${e.daysRemaining}
Bitiş Tarihi: ${r}
Panel: ${o}
Ayarlar: ${i}`}}function h(e){let t=e.timezone||"Europe/Istanbul",r=(0,p.v)(e.occurredAt,t),o=e.downMonitors.length,i=`${u()}/dashboard/incidents`,a=`${u()}/dashboard/settings`,n=e.downMonitors.slice(0,50).map(e=>`<li><strong>${e.name}</strong> (${e.url}) — <span style="color:#dc2626;">${e.reason}</span></li>`).join("");return{subject:`🚨 [TOPLU ALARM] ${o} web sitesi aynı anda kapandı!`,html:b(`Toplu Kesinti Uyarısı (${o} Site)`,"#991b1b",`<p><strong>Alarm Fırtınası Koruması:</strong> Kısa s\xfcre i\xe7inde <strong>${o}</strong> sitenizde eşzamanlı kesinti tespit edildi. Gelen kutunuzu korumak adına bu bildirim tek e-postada birleştirilmiştir.</p>
     <p>Tespit Zamanı (${t}): <strong>${r}</strong></p>
     <ul style="padding-left:20px; line-height:1.7;">${n}</ul>
     <p><a href="${i}" style="display:inline-block; background:#991b1b; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">T\xfcm Kesintileri G\xf6r\xfcnt\xfcle</a></p>`),text:`[TOPLU ALARM] ${o} site aynı anda kapandı (${r})
`+e.downMonitors.map(e=>`- ${e.name} (${e.url}): ${e.reason}`).join("\n")+`
Panel: ${i}
Ayarlar: ${a}`}}function $(e){let t=`${u()}/dashboard`,r=`${u()}/dashboard/settings`;return{subject:`📊 Artakip ${e.periodLabel} Uptime \xd6zeti — %${e.overallUptimePercent} Uptime`,html:b(`${e.periodLabel} Uptime Raporu`,"#1d4ed8",`<p>${e.periodLabel} web sitesi izleme \xf6zetiniz aşağıdadır:</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">Toplam İzlenen Site</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.totalMonitors}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">Şu An Kapalı Site Sayısı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.downMonitorsCount}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">D\xf6nem İ\xe7i Toplam Kesinti Olayı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.incidentsCount}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">Ortalama Uptime Oranı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#16a34a;"><strong>%${e.overallUptimePercent}</strong></td></tr>
     </table>
     <p><a href="${t}" style="display:inline-block; background:#1d4ed8; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Panele Git</a></p>`),text:`Artakip ${e.periodLabel} \xd6zet
Toplam Site: ${e.totalMonitors}
Şu An Kapalı: ${e.downMonitorsCount}
Kesinti Sayısı: ${e.incidentsCount}
Uptime: %${e.overallUptimePercent}
Panel: ${t}
Ayarlar: ${r}`}}function k(e,t){let r=t.name||"Kullanıcı";return"VERIFY"===e?{subject:"Artakip — E-posta Adresinizi Doğrulayın",html:b("E-posta Doğrulama","#2563eb",`<p>Merhaba <strong>${r}</strong>,</p>
         <p>Artakip hesabınızı etkinleştirmek ve kesinti bildirimlerini alabilmek i\xe7in l\xfctfen e-posta adresinizi doğrulayın:</p>
         <p><a href="${t.actionUrl}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">E-postamı Doğrula</a></p>`),text:`Merhaba ${r}, e-posta adresinizi doğrulamak i\xe7in tıklayın: ${t.actionUrl}`}:"RESET"===e?{subject:"Artakip — Şifre Sıfırlama Talebi",html:b("Şifre Sıfırlama","#2563eb",`<p>Merhaba <strong>${r}</strong>,</p>
         <p>Şifrenizi sıfırlamak i\xe7in aşağıdaki bağlantıya tıklayın (1 saat ge\xe7erlidir):</p>
         <p><a href="${t.actionUrl}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Şifremi Sıfırla</a></p>`),text:`Merhaba ${r}, şifrenizi sıfırlamak i\xe7in tıklayın: ${t.actionUrl}`}:"VERIFY_CONTACT"===e?{subject:"Artakip — Ek Bildirim E-posta Doğrulaması",html:b("Bildirim E-postası Doğrulama","#2563eb",`<p>Bu e-posta adresi Artakip uptime bildirim alıcısı olarak eklendi. Onaylamak i\xe7in tıklayın:</p>
         <p><a href="${t.actionUrl}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Adresi Onayla</a></p>`),text:`Bildirim e-posta adresini onaylamak i\xe7in tıklayın: ${t.actionUrl}`}:{subject:"Artakip'e Hoş Geldiniz!",html:b("Hoş Geldiniz","#16a34a",`<p>Merhaba <strong>${r}</strong>,</p>
       <p>Artakip Uptime İzleme platformuna hoş geldiniz! Hemen ilk web sitenizi ekleyerek 7/24 izlemeye başlayabilirsiniz.</p>
       <p><a href="${t.actionUrl}" style="display:inline-block; background:#16a34a; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Panele Git</a></p>`),text:`Artakip'e hoş geldiniz ${r}! Panel: ${t.actionUrl}`}}async function S(e){let t=e.maxRetries??3,r=process.env.SMTP_HOST,o=Number(process.env.SMTP_PORT||587),a="true"===process.env.SMTP_SECURE,l=process.env.SMTP_USER,p=process.env.SMTP_PASS,f=function(){let e=[],t=process.env.SMTP_FROM;t&&!t.includes("example.com")&&e.push(t),process.env.SMTP_USER&&process.env.SMTP_USER.includes("@")&&e.push(`Artakip Uptime <${process.env.SMTP_USER}>`);try{let t=n().homedir(),r=d().join(t,"etc");if(i().existsSync(r))for(let t of i().readdirSync(r,{withFileTypes:!0})){if(!t.isDirectory())continue;let o=t.name,a=d().join(r,o,"passwd");if(i().existsSync(a))for(let t of i().readFileSync(a,"utf8").split(/\r?\n/).filter(Boolean)){let r=t.split(":")[0]?.trim();r&&e.push(`Artakip Uptime <${r}@${o}>`)}}}catch{}try{let t=n().userInfo().username,r=n().hostname();t&&r&&e.push(`Artakip Uptime <${t}@${r}>`)}catch{}return e.push("Artakip Uptime <noreply@artovy.com>"),Array.from(new Set(e))}(),c=f[0]||"Artakip Uptime <noreply@artovy.com>",u="",b=!!(r&&"smtp.example.com"!==r);for(let i=1;i<=t;i++)try{if(b){let t=s.createTransport({host:r,port:o,secure:a,auth:l&&"apikey"!==l?{user:l,pass:p}:void 0,tls:{rejectUnauthorized:!1},connectionTimeout:6e3});await t.sendMail({from:c,to:e.toEmail,subject:e.template.subject,text:e.template.text,html:e.template.html})}else if("linux"===process.platform){let t=!1,r="";for(let o of f)try{let r=function(e){let t=/<([^>]+)>/.exec(e);return t?t[1]:e.trim()}(o),i=s.createTransport({sendmail:!0,newline:"unix",path:"/usr/sbin/sendmail",args:["-f",r]});await i.sendMail({from:o,to:e.toEmail,subject:e.template.subject,text:e.template.text,html:e.template.html}),t=!0;break}catch(e){r=e instanceof Error?e.message:String(e)}if(!t)for(let o of f)try{let r=s.createTransport({host:"127.0.0.1",port:25,secure:!1,tls:{rejectUnauthorized:!1},connectionTimeout:5e3});await r.sendMail({from:o,to:e.toEmail,subject:e.template.subject,text:e.template.text,html:e.template.html}),t=!0;break}catch(e){r=e instanceof Error?e.message:String(e)}if(!t)throw Error(r||"Yerel Exim/sendmail g\xf6nderimi başarısız oldu.")}else console.log(`[EMAIL-SIMULATED] To: ${e.toEmail} | Subject: ${e.template.subject}`);return await m._B.notificationLog.create({data:{userId:e.userId,monitorId:e.monitorId??null,type:e.type,toEmail:e.toEmail,success:!0}}),{success:!0}}catch(e){u=e instanceof Error?e.message:String(e),i<t&&await new Promise(e=>setTimeout(e,500*i))}try{await m._B.notificationLog.create({data:{userId:e.userId,monitorId:e.monitorId??null,type:e.type,toEmail:e.toEmail,success:!1,error:u}})}catch{}return{success:!1,error:u}}async function T(e){let t=[];e.webhookUrl&&t.push(fetch(e.webhookUrl,{method:"POST",headers:{"Content-Type":"application/json","User-Agent":"TakipBot/1.0"},body:JSON.stringify(e.payload)}).catch(()=>null)),e.slackWebhookUrl&&t.push(fetch(e.slackWebhookUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:e.text})}).catch(()=>null));let r=process.env.TELEGRAM_BOT_TOKEN;r&&e.telegramChatId&&t.push(fetch(`https://api.telegram.org/bot${r}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:e.telegramChatId,text:e.text})}).catch(()=>null)),await Promise.allSettled(t)}},82208:(e,t,r)=>{r.d(t,{_B:()=>i});var o=r(53524);let i=globalThis.prisma??new o.PrismaClient({log:["error"]})},39812:(e,t,r)=>{r.d(t,{cn:()=>a,n:()=>l,v:()=>n});var o=r(36272),i=r(51472);function a(...e){return(0,i.m6)((0,o.W)(e))}function n(e,t="Europe/Istanbul"){if(!e)return"-";let r="string"==typeof e?new Date(e):e;if(isNaN(r.getTime()))return"-";try{return new Intl.DateTimeFormat("tr-TR",{dateStyle:"short",timeStyle:"medium",timeZone:t}).format(r)}catch{return r.toLocaleString("tr-TR")}}function l(e){e<0&&(e=0);let t=Math.floor(e/1e3),r=Math.floor(t/86400),o=Math.floor(t%86400/3600),i=Math.floor(t%3600/60),a=t%60,n=[];return r>0&&n.push(`${r} g\xfcn`),o>0&&n.push(`${o} sa`),i>0&&n.push(`${i} dk`),(a>0||0===n.length)&&n.push(`${a} sn`),n.join(" ")}}};