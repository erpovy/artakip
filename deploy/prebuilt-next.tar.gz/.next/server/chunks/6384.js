"use strict";exports.id=6384,exports.ids=[6384],exports.modules={36384:(e,t,o)=>{o.d(t,{GB:()=>u,I8:()=>b,Mr:()=>d,NR:()=>p,PY:()=>g,Qx:()=>c,XZ:()=>x,l4:()=>n,n_:()=>f,wI:()=>m});var r=o(56742),i=o(39812),a=o(82208);function n(e){return e.userEmailVerified?"DOWN"!==e.eventType||e.notifyOnDown?"UP"!==e.eventType||e.notifyOnUp?"SSL"!==e.eventType||e.notifyOnSslExpiry?!function(e,t,o,r="Europe/Istanbul"){let i;if(!t||!o)return!1;let a=e=>{let t=/^(\d{1,2}):(\d{2})$/.exec(e.trim());if(!t)return null;let o=Number(t[1]),r=Number(t[2]);return o<0||o>23||r<0||r>59?null:60*o+r},n=a(t),d=a(o);if(null===n||null===d||n===d)return!1;try{let t=new Intl.DateTimeFormat("en-GB",{hour:"2-digit",minute:"2-digit",hour12:!1,timeZone:r}).formatToParts(e),o=Number(t.find(e=>"hour"===e.type)?.value??0),a=Number(t.find(e=>"minute"===e.type)?.value??0);i=o%24*60+a}catch{i=60*e.getUTCHours()+e.getUTCMinutes()}return n<d?i>=n&&i<d:i>=n||i<d}(e.now??new Date,e.quietHoursStart,e.quietHoursEnd,e.timezone)?{shouldSendNow:!0,deferForQuietHours:!1}:{shouldSendNow:!1,deferForQuietHours:!0,reason:"Sessiz saatler aktif; bildirim sessiz saat bitişinde toplu g\xf6nderilecek."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı SSL bildirimlerini kapattı."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı a\xe7ılma bildirimlerini kapattı."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı kapanma bildirimlerini kapattı."}:{shouldSendNow:!1,deferForQuietHours:!1,reason:"Kullanıcı e-posta adresi doğrulanmamış."}}function d(e,t=20){return e>=t}function l(){return process.env.NEXT_PUBLIC_APP_URL||process.env.NEXTAUTH_URL||"http://localhost:3000"}function s(e,t,o){let r=`${l()}/dashboard/settings`;return`<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>${e}</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#f8fafc; padding:24px; color:#0f172a;">
  <div style="max-width:600px; margin:0 auto; background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; overflow:hidden;">
    <div style="background:${t}; color:#ffffff; padding:16px 24px; font-weight:700; font-size:18px;">
      Artakip Uptime — ${e}
    </div>
    <div style="padding:24px; line-height:1.6; font-size:15px;">
      ${o}
    </div>
    <div style="background:#f1f5f9; padding:16px 24px; font-size:12px; color:#64748b; border-top:1px solid #e2e8f0;">
      Bu e-posta Artakip Uptime izleme servisiniz tarafından otomatik g\xf6nderilmiştir.<br/>
      <a href="${r}" style="color:#2563eb; text-decoration:underline;">Bildirim ayarlarını değiştir veya abonelikten \xe7ık</a>
    </div>
  </div>
</body>
</html>`}function p(e){let t=e.timezone||"Europe/Istanbul",o=(0,i.v)(e.startedAt,t),r=`${l()}/dashboard/monitors/${e.monitorId}`,a=`${l()}/dashboard/settings`;return{subject:`🔴 [KAPANDI] ${e.monitorName} erişilemiyor`,html:s("Site Kapandı Uyarısı","#dc2626",`<p><strong>${e.monitorName}</strong> isimli web siteniz yapılan kontrolde yanıt vermedi.</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Site Adı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.monitorName}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">URL</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><a href="${e.url}">${e.url}</a></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Kapanma Zamanı (${t})</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;">${o}</td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Hata Nedeni</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#dc2626;">${e.reason}</td></tr>
     </table>
     <p style="margin-top:20px;">
       <a href="${r}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Panelde G\xf6r\xfcnt\xfcle</a>
     </p>`),text:`[KAPANDI] ${e.monitorName}
URL: ${e.url}
Kapanma Zamanı (${t}): ${o}
Hata Nedeni: ${e.reason}
Panel: ${r}
Bildirim Ayarları / Abonelikten \xc7ık: ${a}`}}function m(e){let t=e.timezone||"Europe/Istanbul",o=(0,i.v)(e.resolvedAt,t),r=(0,i.n)(e.durationMs),a=`${l()}/dashboard/monitors/${e.monitorId}`,n=`${l()}/dashboard/settings`;return{subject:`🟢 [A\xc7ILDI] ${e.monitorName} tekrar yayında (${r} kesinti)`,html:s("Site Tekrar A\xe7ıldı","#16a34a",`<p><strong>${e.monitorName}</strong> isimli web siteniz tekrar erişilebilir duruma geldi.</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Site Adı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.monitorName}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">URL</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><a href="${e.url}">${e.url}</a></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">A\xe7ılma Zamanı (${t})</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;">${o}</td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Toplam Kesinti S\xfcresi</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; font-weight:700;">${r}</td></tr>
     </table>
     <p style="margin-top:20px;">
       <a href="${a}" style="display:inline-block; background:#16a34a; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Olay Ge\xe7mişini İncele</a>
     </p>`),text:`[A\xc7ILDI] ${e.monitorName}
URL: ${e.url}
A\xe7ılma Zamanı (${t}): ${o}
Toplam Kesinti S\xfcresi: ${r}
Panel: ${a}
Bildirim Ayarları / Abonelikten \xc7ık: ${n}`}}function f(e){let t=e.timezone||"Europe/Istanbul",o=(0,i.v)(e.expiresAt,t),r=`${l()}/dashboard/monitors/${e.monitorId}`,a=`${l()}/dashboard/settings`;return{subject:`⚠️ [SSL UYARISI] ${e.monitorName} SSL sertifikasının bitmesine ${e.daysRemaining} g\xfcn kaldı`,html:s("SSL Sertifika S\xfcresi Doluyor","#d97706",`<p><strong>${e.monitorName}</strong> sitenizin SSL sertifikasının s\xfcresi yakında dolacaktır.</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Site Adı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.monitorName}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Kalan G\xfcn</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#d97706; font-weight:700;">${e.daysRemaining} g\xfcn</td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#64748b;">Bitiş Tarihi</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;">${o}</td></tr>
     </table>
     <p><a href="${r}" style="display:inline-block; background:#d97706; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Site Detayına Git</a></p>`),text:`[SSL UYARISI] ${e.monitorName} (${e.url})
Kalan G\xfcn: ${e.daysRemaining}
Bitiş Tarihi: ${o}
Panel: ${r}
Ayarlar: ${a}`}}function b(e){let t=e.timezone||"Europe/Istanbul",o=(0,i.v)(e.occurredAt,t),r=e.downMonitors.length,a=`${l()}/dashboard/incidents`,n=`${l()}/dashboard/settings`,d=e.downMonitors.slice(0,50).map(e=>`<li><strong>${e.name}</strong> (${e.url}) — <span style="color:#dc2626;">${e.reason}</span></li>`).join("");return{subject:`🚨 [TOPLU ALARM] ${r} web sitesi aynı anda kapandı!`,html:s(`Toplu Kesinti Uyarısı (${r} Site)`,"#991b1b",`<p><strong>Alarm Fırtınası Koruması:</strong> Kısa s\xfcre i\xe7inde <strong>${r}</strong> sitenizde eşzamanlı kesinti tespit edildi. Gelen kutunuzu korumak adına bu bildirim tek e-postada birleştirilmiştir.</p>
     <p>Tespit Zamanı (${t}): <strong>${o}</strong></p>
     <ul style="padding-left:20px; line-height:1.7;">${d}</ul>
     <p><a href="${a}" style="display:inline-block; background:#991b1b; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">T\xfcm Kesintileri G\xf6r\xfcnt\xfcle</a></p>`),text:`[TOPLU ALARM] ${r} site aynı anda kapandı (${o})
`+e.downMonitors.map(e=>`- ${e.name} (${e.url}): ${e.reason}`).join("\n")+`
Panel: ${a}
Ayarlar: ${n}`}}function u(e){let t=`${l()}/dashboard`,o=`${l()}/dashboard/settings`;return{subject:`📊 Artakip ${e.periodLabel} Uptime \xd6zeti — %${e.overallUptimePercent} Uptime`,html:s(`${e.periodLabel} Uptime Raporu`,"#1d4ed8",`<p>${e.periodLabel} web sitesi izleme \xf6zetiniz aşağıdadır:</p>
     <table style="width:100%; border-collapse:collapse; margin:16px 0;">
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">Toplam İzlenen Site</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.totalMonitors}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">Şu An Kapalı Site Sayısı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.downMonitorsCount}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">D\xf6nem İ\xe7i Toplam Kesinti Olayı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0;"><strong>${e.incidentsCount}</strong></td></tr>
       <tr><td style="padding:8px; border-bottom:1px solid #e2e8f0;">Ortalama Uptime Oranı</td><td style="padding:8px; border-bottom:1px solid #e2e8f0; color:#16a34a;"><strong>%${e.overallUptimePercent}</strong></td></tr>
     </table>
     <p><a href="${t}" style="display:inline-block; background:#1d4ed8; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Panele Git</a></p>`),text:`Artakip ${e.periodLabel} \xd6zet
Toplam Site: ${e.totalMonitors}
Şu An Kapalı: ${e.downMonitorsCount}
Kesinti Sayısı: ${e.incidentsCount}
Uptime: %${e.overallUptimePercent}
Panel: ${t}
Ayarlar: ${o}`}}function c(e,t){let o=t.name||"Kullanıcı";return"VERIFY"===e?{subject:"Artakip — E-posta Adresinizi Doğrulayın",html:s("E-posta Doğrulama","#2563eb",`<p>Merhaba <strong>${o}</strong>,</p>
         <p>Artakip hesabınızı etkinleştirmek ve kesinti bildirimlerini alabilmek i\xe7in l\xfctfen e-posta adresinizi doğrulayın:</p>
         <p><a href="${t.actionUrl}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">E-postamı Doğrula</a></p>`),text:`Merhaba ${o}, e-posta adresinizi doğrulamak i\xe7in tıklayın: ${t.actionUrl}`}:"RESET"===e?{subject:"Artakip — Şifre Sıfırlama Talebi",html:s("Şifre Sıfırlama","#2563eb",`<p>Merhaba <strong>${o}</strong>,</p>
         <p>Şifrenizi sıfırlamak i\xe7in aşağıdaki bağlantıya tıklayın (1 saat ge\xe7erlidir):</p>
         <p><a href="${t.actionUrl}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Şifremi Sıfırla</a></p>`),text:`Merhaba ${o}, şifrenizi sıfırlamak i\xe7in tıklayın: ${t.actionUrl}`}:"VERIFY_CONTACT"===e?{subject:"Artakip — Ek Bildirim E-posta Doğrulaması",html:s("Bildirim E-postası Doğrulama","#2563eb",`<p>Bu e-posta adresi Artakip uptime bildirim alıcısı olarak eklendi. Onaylamak i\xe7in tıklayın:</p>
         <p><a href="${t.actionUrl}" style="display:inline-block; background:#2563eb; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Adresi Onayla</a></p>`),text:`Bildirim e-posta adresini onaylamak i\xe7in tıklayın: ${t.actionUrl}`}:{subject:"Artakip'e Hoş Geldiniz!",html:s("Hoş Geldiniz","#16a34a",`<p>Merhaba <strong>${o}</strong>,</p>
       <p>Artakip Uptime İzleme platformuna hoş geldiniz! Hemen ilk web sitenizi ekleyerek 7/24 izlemeye başlayabilirsiniz.</p>
       <p><a href="${t.actionUrl}" style="display:inline-block; background:#16a34a; color:#ffffff; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:600;">Panele Git</a></p>`),text:`Artakip'e hoş geldiniz ${o}! Panel: ${t.actionUrl}`}}async function x(e){let t=e.maxRetries??3,o=process.env.SMTP_HOST,i=Number(process.env.SMTP_PORT||587),n="true"===process.env.SMTP_SECURE,d=process.env.SMTP_USER,l=process.env.SMTP_PASS,s=process.env.SMTP_FROM||"Artakip Uptime <bildirim@artakip.com>",p="";for(let m=1;m<=t;m++)try{if(!o||"smtp.example.com"===o)return console.log(`[EMAIL-SIMULATED] To: ${e.toEmail} | Subject: ${e.template.subject}`),await a._B.notificationLog.create({data:{userId:e.userId,monitorId:e.monitorId??null,type:e.type,toEmail:e.toEmail,success:!0}}),{success:!0};let t=r.createTransport({host:o,port:i,secure:n,auth:d?{user:d,pass:l}:void 0});return await t.sendMail({from:s,to:e.toEmail,subject:e.template.subject,text:e.template.text,html:e.template.html}),await a._B.notificationLog.create({data:{userId:e.userId,monitorId:e.monitorId??null,type:e.type,toEmail:e.toEmail,success:!0}}),{success:!0}}catch(e){p=e instanceof Error?e.message:String(e),m<t&&await new Promise(e=>setTimeout(e,500*m))}try{await a._B.notificationLog.create({data:{userId:e.userId,monitorId:e.monitorId??null,type:e.type,toEmail:e.toEmail,success:!1,error:p}})}catch{}return{success:!1,error:p}}async function g(e){let t=[];e.webhookUrl&&t.push(fetch(e.webhookUrl,{method:"POST",headers:{"Content-Type":"application/json","User-Agent":"TakipBot/1.0"},body:JSON.stringify(e.payload)}).catch(()=>null)),e.slackWebhookUrl&&t.push(fetch(e.slackWebhookUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:e.text})}).catch(()=>null));let o=process.env.TELEGRAM_BOT_TOKEN;o&&e.telegramChatId&&t.push(fetch(`https://api.telegram.org/bot${o}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:e.telegramChatId,text:e.text})}).catch(()=>null)),await Promise.allSettled(t)}},82208:(e,t,o)=>{o.d(t,{_B:()=>i});var r=o(53524);let i=globalThis.prisma??new r.PrismaClient({log:["error"]})},39812:(e,t,o)=>{o.d(t,{cn:()=>a,n:()=>d,v:()=>n});var r=o(36272),i=o(51472);function a(...e){return(0,i.m6)((0,r.W)(e))}function n(e,t="Europe/Istanbul"){if(!e)return"-";let o="string"==typeof e?new Date(e):e;if(isNaN(o.getTime()))return"-";try{return new Intl.DateTimeFormat("tr-TR",{dateStyle:"short",timeStyle:"medium",timeZone:t}).format(o)}catch{return o.toLocaleString("tr-TR")}}function d(e){e<0&&(e=0);let t=Math.floor(e/1e3),o=Math.floor(t/86400),r=Math.floor(t%86400/3600),i=Math.floor(t%3600/60),a=t%60,n=[];return o>0&&n.push(`${o} g\xfcn`),r>0&&n.push(`${r} sa`),i>0&&n.push(`${i} dk`),(a>0||0===n.length)&&n.push(`${a} sn`),n.join(" ")}}};